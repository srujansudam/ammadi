////////////////////////////////////////////////////////////////////////////////
// IOWarrior control class
// test program
////////////////////////////////////////////////////////////////////////////////
/**
 * \file main.cpp
 *
 * \brief provides the test cases for the IOWarrior control class.
 */
#include <iostream>
using namespace std;
#include "CIOWarrior.h"

/**
 * \brief Test of the basic functionality of the class.
 */
void iow_basic_test();

/**
 * \brief Test of the classes state machine.
 * The device has to be connected at start time, because the API doesn't recognize a newly plugged device during runtime of the program.
 * During runtime (duration is about 12 cycles of the running light) the device may be unplugged and plugged again.
 * If the device is unplugged, the data are printed on the screen (binary format). If it is plugged again, the running light continues.
 */
void iow_runningLight_test();

int main (void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
	cout << "IOWarrior output test started." << endl << endl;
	iow_basic_test();
	iow_runningLight_test();
	cout << "Bye!" << endl << endl;
	return 0;
}

void iow_basic_test()
{
	CIOWarrior myWarrior;
	cout << "basic test" << endl;
	cout << "Object state after creation" << endl;
	myWarrior.printState();
	cout << "Try to write before open" << endl;
	myWarrior.write(0xf0);
	myWarrior.printState();

	myWarrior.open();
	cout << "Object state after open" << endl;
	myWarrior.printState();
	cout << "Try to write after open" << endl;
	myWarrior.write(0xf0);
	myWarrior.printState();
	cout << "Object state after close" << endl;
	myWarrior.close();
	myWarrior.printState();
	cout << endl;
}

void iow_runningLight_test()
{
	cout << "running light test" << endl;
	CIOWarrior myWarrior;
	bool bWarrior=true;

	if(false == myWarrior.open())
	{
		cout << "Can only print data! Please, make sure that an IOWarrior 40 is connected at start time!" << endl;
		myWarrior.printState();
		bWarrior=false;
	}

	char data=1;
	for(int i=0; i<=100; i++)
	{
		if(false == bWarrior)
		{
			myWarrior.printData(data); 		// print LED data, no device connected at start time
		}
		else if (false == myWarrior.write(data))	// if write fails (tested by unplugging and plugging the device)
		{
			myWarrior.printData(data); 		// print LED data
			myWarrior.open();				// try to reopen the device
		}
		Sleep(250);
		data=data << 1;
		if(0==data)data=1;
	}
	myWarrior.close();
}
