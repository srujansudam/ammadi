/*
 * CAmpMeter.cpp
 *
 *  Created on: 21.10.2019
 *      Author: Wirth
 */
#include <iostream>
//#include <stdlib.h>
#include <math.h>
using namespace std;

#include "CIOWarrior.h"
#include "CAmpMeter.h"

CAmpMeter::CAmpMeter()
{
	// todo: initialize all attributes (see UML class diagram)
}

void CAmpMeter::init(float min, float max, SCALING_MODES scmode, int logScaleMin,CIOWarrior* iowdev)
{
	// todo: initialize the amplitude meter on the basis of the given parameter values
	// The maximum absolute value of min and max is taken for the maximum of the scale.
	// The thresholds are calculated for a LED line with 8 LEDs in dependence of the given scaling mode (scmode).
		// Linear scaling: 0 ... maximum of the scale
		// Logarithmic scaling: logScaleMin ... 0 [dB], logScaleMin must be negative
}

bool CAmpMeter::write(float* databuf, unsigned long databufsize)
{
	if(NULL == databuf || NULL==m_iowdev)return false;
	return write(_getValueFromBuffer(databuf, databufsize));
}

bool CAmpMeter::write(float data)
{
	// todo:
	// if an IOWarrior is connected it gets the appropriate bar pattern and writes it to the IOWarrior
	// otherwise it does nothing
	return false;
}

void CAmpMeter::print(float data)
{
	//todo:
	// get the appropriate bar pattern
	// print the bar pattern in binary format on the screen (see CIOWarrior::printData() method for an example)
}

void CAmpMeter::print(float* databuf, unsigned long databufsize)
{
	if(NULL == databuf)
	{
		cout << "no data for printing amplitude bar!" << endl;
		return;
	}
	return print(_getValueFromBuffer(databuf, databufsize));
}


unsigned char CAmpMeter::_getBarPattern(float data)
{
	char pat=0;
	// todo: Calculate appropriate bar pattern pat for data. Data is a linear value in any case. The bar pattern may be used
	// for visualization on the screen or the LED line.
	// Example: pat is 0b11111111 if the absolute value of data is equal to the maximum data value (m_scMax)
	// In dependence of the scaling mode (m_scmode), the absolute value of data (linear scaling) or
	// the dB value of the absolute value of data (logarithmic scaling) has to be used for the bar pattern calculation.
	// Before calculating the dB value, the absolute value of data shall be divided by the linear scale maximum to
	// adjust the highest value to 0 dB (this is called peak normalization).
	return pat;
}


float CAmpMeter::_getValueFromBuffer(float* databuf, unsigned long databufsize)
{
	float dmax=0., d;
	unsigned long imax=0;
	for(unsigned long i=0; i < databufsize; i++)
	{
		d=fabs(databuf[i]);
		if(dmax < d)
		{
			dmax=d;
			imax=i;
		}
	}
	return databuf[imax];
}
